CONNNAME = "BCGW"
CONNSERVER = 'bcgw.bcgov'
CONNPORT = '1521'
CONNDBQ = 'idwprod1'
CONNPLATFORM = "ORACLE"
CONNINSTANCE = "bcgw.bcgov/idwprod1.bcgov"

# #TEST ENV CONNECTION SETTINGS
# CONNNAME = "BCGW_TEST"
# CONNSERVER = 'bcgw-i.bcgov'
# CONNPORT = '1521'
# CONNDBQ = 'idwdlvr1'
# CONNPLATFORM = "ORACLE"
# CONNINSTANCE = "bcgw-i.bcgov/idwdlvr1.bcgov"