########FILES REMOVED########
The beta files have been removed as the scripts have moved to the production tool as of Oct 23, 2024.
As new features are developed and we require real-world testing, the updated scripts will be available
here once again. If you have any questions, please contact Steve Richards (Steve.Richards@gov.bc.ca).